from rest_framework import serializers 
from .models import Student 

class Studentserializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model=Student 
        fields=['url','rn','stuname','address','contact']
