from rest_framework import viewsets
from .serializer import Studentserializer
from .models import Student
# Create your views here.

class StudentViewSet(viewsets.ModelViewSet):
    queryset=Student.objects.all()
    serializer_class=Studentserializer
